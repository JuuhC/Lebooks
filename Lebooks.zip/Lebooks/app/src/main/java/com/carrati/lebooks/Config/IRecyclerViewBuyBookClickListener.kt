package com.carrati.lebooks.Config

import android.view.View

interface IRecyclerViewBuyBookClickListener {

    fun onClickBuyBook(position: Int)

}
