package com.carrati.lebooks.Config

interface IRecyclerViewFavClickListener {

    fun onClickFavBook(position: Int)

}
